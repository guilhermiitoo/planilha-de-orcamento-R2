# R2 Energy — site vitrine (v1.0)

Site estático em HTML/CSS/JS puro — sem instalação, sem build.

## Como abrir
- Localmente: abra `index.html` no navegador. Para a detecção de localização funcionar (GPS), abra por um servidor simples, ex.: `python -m http.server` e acesse `http://localhost:8000`.
- Online: suba a pasta inteira (Netlify, Vercel, GitHub Pages ou a hospedagem da empresa).

## Arquivos
| Arquivo | Função |
|---|---|
| `index.html` | Estrutura da página |
| `styles.css` | Visual (paleta nas variáveis do `:root`, no topo) |
| `content.js` | **Todos os textos, números, telefone, CNPJ e parâmetros do simulador** |
| `app.js` | Scroll scrubbing, modo "Saiba mais", simulador |
| `assets/` | Quadros, vídeos e imagens — veja `assets/README.md` |

## O que você troca sozinho (sem programar)
- Textos, etapas, ficha técnica, telefone/WhatsApp, CNPJ, e-mail → `content.js`
- Tarifa (R$/kWh), custo por Wp, radiação por cidade → `content.js` → `simulador`
- Cores e fontes → `styles.css` → bloco `:root`
- Imagens e vídeos → pasta `assets/` (nomes em `assets/README.md`)

## Como funciona o scroll scrubbing (resumo)
Cada seção tem 520 % da altura da tela. Um bloco fica "preso" (sticky) enquanto você rola; o `app.js` calcula a fração rolada (0 → 1) e escolhe o quadro `frame_XX.jpg` correspondente. Rolar para cima recalcula — por isso volta. Os 16 % finais são a pausa no último quadro antes da página deslizar para a próxima seção.
