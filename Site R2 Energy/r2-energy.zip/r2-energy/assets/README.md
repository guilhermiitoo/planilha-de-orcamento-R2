# Pasta de assets — onde colar imagens e vídeos

O código já está programado para procurar os arquivos abaixo. Basta colar com o nome exato.

## assets/residencial/
| Arquivo | O que é |
|---|---|
| `frame_01.jpg` … `frame_15.jpg` | Os 15 quadros da placa descendo até encaixar no telhado (JPG, mesma proporção, ex.: 1920×1080). Só são usados quando **todos os 15** existirem. |
| `base.png` | Imagem única usada enquanto os 15 quadros não existem (já vem preenchida). |
| `instalacao.mp4` | Vídeo da instalação exibido ao clicar em "Saiba mais" (MP4 H.264, 16:9). |

## assets/corporativo/
| Arquivo | O que é |
|---|---|
| `frame_01.jpg` … `frame_15.jpg` | Os 15 quadros da placa no galpão/laje. |
| `base.jpg` | (opcional) imagem única de reserva — ative em `content.js` → `fundoBase`. |
| `instalacao.mp4` | Vídeo da instalação corporativa. |

## assets/referencia/
Imagens de referência usadas para criar o site. Não são carregadas pela página.

Dica: exporte os 15 quadros de um vídeo com o mesmo tamanho e sem mudar o enquadramento — a troca fica instantânea porque o site pré-carrega todos antes de exibir.
